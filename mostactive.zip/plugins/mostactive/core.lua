function GetPluginAuthor()
    return "Swiftly Solutions"
end

function GetPluginVersion()
    return "1.0.0"
end

function GetPluginName()
    return "Most Active"
end

function GetPluginWebsite()
    return "https://github.com/swiftly-solution/mostactive"
end